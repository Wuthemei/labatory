export const footerColor = "#111319";
export const sidebarColor = "#1d2d42";
